import { FormEvent, useEffect, useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowRight,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Instagram,
  MapPin,
  Menu,
  MessageCircle,
  Minus,
  Phone,
  Plus,
  ShoppingBag,
  Star,
  UtensilsCrossed,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const mapLink = "https://share.google/l2G73Ea4o4TdpSBVz";
const menuSource = "https://fr.restaurantguru.com/Restaurant-Per-Voi-Sousse/menu";
const whatsappLink = "https://wa.me/21620217090?text=Bonjour%20Per%20Voi%2C%20je%20souhaite%20r%C3%A9server%20une%20table%20ou%20poser%20une%20question.";
const googleReviewLink = "https://www.google.com/search?q=per+voi+sousse+avis&oq=per+voi+sousse+avis&sourceid=chrome&ie=UTF-8#lrd=0x12fd8b00228081c7:0x86eae71c78023075,3,,,,";

type Language = "fr" | "ar" | "en" | "it";
const languageLabels: Record<Language, string> = { fr: "Français", ar: "العربية", en: "English", it: "Italiano" };
const languageFlags: Record<Language, string> = { fr: "🇫🇷", ar: "🇹🇳", en: "🇬🇧", it: "🇮🇹" };
const languageCodes: Record<Language, string> = { fr: "FR", ar: "AR", en: "EN", it: "IT" };
const menuCopy: Record<Language, Record<string, string>> = {
  fr: {},
  en: { "Entrées":"Starters", "Pâtes":"Pasta", "Terre & mer":"Land & sea", "Menu enfant":"Kids menu", "Boissons":"Drinks", "Burrata":"Burrata", "Rigatoni Effiloché de Bœuf":"Pulled Beef Rigatoni", "La Margherita":"Margherita", "Tiramisu":"Tiramisu", "Marmelade de tomates, pickles de gingembre et crème citronnée.":"Tomato marmalade, ginger pickles and lemon cream.", "Sauce tomates, tomates séchées et crème de parmesan.":"Tomato sauce, sun-dried tomatoes and parmesan cream.", "Miel, noisettes et figues séchées.":"Honey, hazelnuts and dried figs.", "Mozzarella, grana padano, basilic frais et huile d’olives.":"Mozzarella, grana padano, fresh basil and olive oil.", "Café, mascarpone, langues de chat et cacao.":"Coffee, mascarpone, ladyfingers and cocoa." },
  it: { "Entrées":"Antipasti", "Pâtes":"Pasta", "Terre & mer":"Terra e mare", "Menu enfant":"Menù bambini", "Boissons":"Bevande", "Burrata":"Burrata", "Rigatoni Effiloché de Bœuf":"Rigatoni con manzo sfilacciato", "La Margherita":"La Margherita", "Tiramisu":"Tiramisù", "Marmelade de tomates, pickles de gingembre et crème citronnée.":"Marmellata di pomodoro, pickles di zenzero e crema al limone.", "Sauce tomates, tomates séchées et crème de parmesan.":"Salsa di pomodoro, pomodori secchi e crema di parmigiano.", "Miel, noisettes et figues séchées.":"Miele, nocciole e fichi secchi.", "Mozzarella, grana padano, basilic frais et huile d’olives.":"Mozzarella, grana padano, basilico fresco e olio d’oliva.", "Café, mascarpone, langues de chat et cacao.":"Caffè, mascarpone, savoiardi e cacao." },
  ar: { "Entrées":"المقبلات", "Pâtes":"المعكرونة", "Terre & mer":"من البر والبحر", "Menu enfant":"قائمة الأطفال", "Boissons":"المشروبات", "Burrata":"بوراتا", "Rigatoni Effiloché de Bœuf":"ريغاتوني بلحم البقر المفتت", "La Margherita":"مارغريتا", "Tiramisu":"تيراميسو", "Marmelade de tomates, pickles de gingembre et crème citronnée.":"مربى الطماطم، مخلل الزنجبيل وكريمة الليمون.", "Sauce tomates, tomates séchées et crème de parmesan.":"صلصة الطماطم، الطماطم المجففة وكريمة البارميزان.", "Miel, noisettes et figues séchées.":"العسل، البندق والتين المجفف.", "Mozzarella, grana padano, basilic frais et huile d’olives.":"موزاريلا، غرانا بادانو، ريحان طازج وزيت الزيتون.", "Café, mascarpone, langues de chat et cacao.":"قهوة، ماسكاربوني، بسكويت وكاكاو." }
};
const menuTokenCopy: Record<Exclude<Language, "fr">, Record<string, string>> = {
  en: { "Selon stock :": "Subject to availability: ", "sauce tomates": "tomato sauce", "sauce tomate": "tomato sauce", "crème": "cream", "tomates séchées": "sun-dried tomatoes", "huile d’olives": "olive oil", "basilic frais": "fresh basil", "basilic": "basil", "persil": "parsley", "crevettes": "shrimp", "poulpes": "octopus", "moules": "mussels", "seiches": "cuttlefish", "bœuf": "beef", "poulet": "chicken", "saumon": "salmon", "champignons de Paris": "button mushrooms", "champignons": "mushrooms", "mozzarella": "mozzarella", "parmesan": "parmesan", "grana padano": "grana padano", "miel": "honey", "noisettes": "hazelnuts", "figues séchées": "dried figs", "citron": "lemon", "orange": "orange", "courgettes": "zucchini", "poivrons": "peppers", "oignons": "onions", "ail confit": "confit garlic", "huile de truffes": "truffle oil", "truffes": "truffle", "pistaches": "pistachios", "roquette": "rocket", "olives": "olives", "frites": "fries", "pâtes": "pasta", "pommes de terre": "potatoes", "épinard": "spinach", "épinards": "spinach", "risotto": "risotto", "jus de bœuf": "beef jus", "pâte fraîche": "fresh pasta", "pâte": "dough", "houmous": "hummus", "tahina": "tahini", "jus de citron": "lemon juice", "fleur de sel": "sea salt", "caramel au lait": "milk caramel", "fruits secs concassés": "crushed nuts", "café": "coffee", "mascarpone": "mascarpone", "poudre de cacao": "cocoa powder", "pain brioché": "brioche bread", "framboises": "raspberries", "menthe": "mint", "chocolat": "chocolate", "œuf": "egg", "salade": "salad", "fromage": "cheese", "croûtons": "croutons", "anchois": "anchovies", "betterave": "beetroot", "melon": "melon", "saumon gravlax": "gravlax salmon", "filet": "fillet", "mille-feuille": "layered", "gingembre": "ginger", "légumes sautés": "sautéed vegetables", "daurade": "sea bream", "caviar d’aubergines": "eggplant caviar", "aubergines": "eggplant", "algue croustillante": "crispy seaweed", "bisque de crevettes": "shrimp bisque", "ricotta": "ricotta", "noix": "walnuts" },
  it: { "Selon stock :": "Secondo disponibilità: ", "sauce tomates": "salsa di pomodoro", "sauce tomate": "salsa di pomodoro", "crème": "crema", "tomates séchées": "pomodori secchi", "huile d’olives": "olio d’oliva", "basilic frais": "basilico fresco", "basilic": "basilico", "persil": "prezzemolo", "crevettes": "gamberi", "poulpes": "polpo", "moules": "cozze", "seiches": "seppie", "bœuf": "manzo", "poulet": "pollo", "saumon": "salmone", "champignons de Paris": "funghi champignon", "champignons": "funghi", "miel": "miele", "noisettes": "nocciole", "figues séchées": "fichi secchi", "citron": "limone", "orange": "arancia", "courgettes": "zucchine", "poivrons": "peperoni", "oignons": "cipolle", "ail confit": "aglio confit", "huile de truffes": "olio al tartufo", "truffes": "tartufo", "pistaches": "pistacchi", "roquette": "rucola", "olives": "olive", "frites": "patatine", "pâtes": "pasta", "pommes de terre": "patate", "épinard": "spinaci", "épinards": "spinaci", "risotto": "risotto", "jus de bœuf": "fondo di manzo", "pâte fraîche": "pasta fresca", "houmous": "hummus", "tahina": "tahina", "jus de citron": "succo di limone", "fleur de sel": "fior di sale", "caramel au lait": "caramello al latte", "fruits secs concassés": "frutta secca tritata", "café": "caffè", "mascarpone": "mascarpone", "poudre de cacao": "cacao in polvere", "pain brioché": "pane brioche", "framboises": "lamponi", "menthe": "menta", "chocolat": "cioccolato", "œuf": "uovo", "salade": "insalata", "fromage": "formaggio", "croûtons": "crostini", "anchois": "acciughe", "betterave": "barbabietola", "melon": "melone", "saumon gravlax": "salmone gravlax", "filet": "filetto", "gingembre": "zenzero", "légumes sautés": "verdure saltate", "daurade": "orata", "caviar d’aubergines": "caviale di melanzane", "aubergines": "melanzane", "algue croustillante": "alga croccante", "bisque de crevettes": "bisque di gamberi", "ricotta": "ricotta", "noix": "noci" },
  ar: { "Selon stock :": "حسب التوفر: ", "sauce tomates": "صلصة الطماطم", "sauce tomate": "صلصة الطماطم", "crème": "كريمة", "tomates séchées": "طماطم مجففة", "huile d’olives": "زيت الزيتون", "basilic frais": "ريحان طازج", "basilic": "ريحان", "persil": "بقدونس", "crevettes": "جمبري", "poulpes": "أخطبوط", "moules": "بلح البحر", "seiches": "حبار", "bœuf": "لحم بقر", "poulet": "دجاج", "saumon": "سلمون", "champignons de Paris": "فطر", "champignons": "فطر", "miel": "عسل", "noisettes": "بندق", "figues séchées": "تين مجفف", "citron": "ليمون", "orange": "برتقال", "courgettes": "كوسة", "poivrons": "فلفل", "oignons": "بصل", "ail confit": "ثوم مطهو", "huile de truffes": "زيت الكمأة", "truffes": "كمأة", "pistaches": "فستق", "roquette": "جرجير", "olives": "زيتون", "frites": "بطاطا مقلية", "pâtes": "معكرونة", "pommes de terre": "بطاطا", "épinard": "سبانخ", "épinards": "سبانخ", "risotto": "ريزوتو", "jus de bœuf": "صلصة لحم البقر", "pâte fraîche": "عجينة طازجة", "houmous": "حمص", "tahina": "طحينة", "jus de citron": "عصير الليمون", "fleur de sel": "ملح البحر", "caramel au lait": "كراميل الحليب", "fruits secs concassés": "مكسرات مجروشة", "café": "قهوة", "mascarpone": "ماسكاربوني", "poudre de cacao": "مسحوق الكاكاو", "pain brioché": "خبز بريوش", "framboises": "توت العليق", "menthe": "نعناع", "chocolat": "شوكولاتة", "œuf": "بيض", "salade": "سلطة", "fromage": "جبن", "croûtons": "خبز محمص", "anchois": "أنشوفة", "betterave": "شمندر", "melon": "شمام", "saumon gravlax": "سلمون جرافلاكس", "filet": "فيليه", "gingembre": "زنجبيل", "légumes sautés": "خضروات مشوحة", "daurade": "دنيس", "caviar d’aubergines": "كافيار الباذنجان", "aubergines": "باذنجان", "algue croustillante": "أعشاب بحرية مقرمشة", "bisque de crevettes": "حساء الجمبري", "ricotta": "ريكوتا", "noix": "جوز" }
};
const translateMenuText = (language: Language, text: string | null | undefined) => {
  if (!text) return "";
  if (language === "fr") return text;
  const exact = menuCopy[language][text];
  if (exact) return exact;
  const translated = Object.entries(menuTokenCopy[language]).sort((a, b) => b[0].length - a[0].length).reduce((value, [from, to]) => value.replaceAll(from, to), text);
  if (language === "en") return translated.replaceAll(" et ", " and ").replaceAll(" de ", " of ").replaceAll(" aux ", " with ").replaceAll(" au ", " with ").replaceAll(" à ", " with ").replaceAll(" fumés", " smoked").replaceAll(" Poivrons", " Peppers").replaceAll(" Crevettes", " Shrimp").replaceAll(" Poulpes", " Octopus").replaceAll(" Fruits de Mer", " Seafood").replaceAll(" Poulet", " Chicken").replaceAll(" Bœuf", " Beef").replaceAll(" Saumon", " Salmon");
  if (language === "it") return translated.replaceAll(" et ", " e ").replaceAll(" de ", " di ").replaceAll(" aux ", " con ").replaceAll(" au ", " con ").replaceAll(" à ", " con ");
  return translated.replaceAll(" et ", " و ").replaceAll(" de ", " من ").replaceAll(" aux ", " مع ").replaceAll(" au ", " مع ").replaceAll(" à ", " مع ");
};
const translations: Record<Language, Record<string, string>> = {
  fr: { house: "La maison", menu: "La carte", gallery: "Galerie", reviews: "Avis", find: "Nous trouver", reserve: "Réserver", reserveTable: "Réserver une table", discover: "Découvrir la carte", story: "Notre histoire", scroll: "Faites défiler", restaurant: "Restaurant italien à Sousse", cuisine: "Cucina italiana, cuore mediterraneo", houseTitle: "Une table italienne avec une âme tunisienne.", menuTitle: "À choisir, à savourer.", completeMenu: "La carte complète", menuFor: "Tous les plats et prix du menu Per Voi.", galleryTitle: "Le goût du détail.", reviewTitle: "Ils parlent de Per Voi.", leaveReview: "Laisser un avis Google", reviewHint: "Votre avis s’ouvre directement dans Google.", bookIntro: "Votre table vous attend.", bookText: "Choisissez un jour et un créneau disponibles.", findUs: "À presto, à Sousse.", add: "Ajouter", officialMenu: "Menu Per Voi", maps: "Ouvrir dans Maps", call: "Nous appeler", host: "Espace hôte", whatsapp: "Réserver sur WhatsApp" },
  en: { house: "The house", menu: "The menu", gallery: "Gallery", reviews: "Reviews", find: "Find us", reserve: "Book", reserveTable: "Book a table", discover: "Discover the menu", story: "Our story", scroll: "Scroll down", restaurant: "Italian restaurant in Sousse", cuisine: "Italian cuisine, Mediterranean heart", houseTitle: "An Italian table with a Tunisian soul.", menuTitle: "Choose, then savor.", completeMenu: "The full menu", menuFor: "All Per Voi dishes and prices.", galleryTitle: "A taste for detail.", reviewTitle: "They talk about Per Voi.", leaveReview: "Leave a Google review", reviewHint: "Your review opens directly in Google.", bookIntro: "Your table is waiting.", bookText: "Choose an available day and time.", findUs: "See you soon in Sousse.", add: "Add", officialMenu: "Per Voi menu", maps: "Open in Maps", call: "Call us", host: "Owner area", whatsapp: "Book on WhatsApp" },
  it: { house: "La casa", menu: "Il menù", gallery: "Galleria", reviews: "Recensioni", find: "Dove trovarci", reserve: "Prenota", reserveTable: "Prenota un tavolo", discover: "Scopri il menù", story: "La nostra storia", scroll: "Scorri", restaurant: "Ristorante italiano a Sousse", cuisine: "Cucina italiana, cuore mediterraneo", houseTitle: "Una tavola italiana con un'anima tunisina.", menuTitle: "Scegli, poi assapora.", completeMenu: "Il menù completo", menuFor: "Tutti i piatti e i prezzi di Per Voi.", galleryTitle: "Il gusto dei dettagli.", reviewTitle: "Parlano di Per Voi.", leaveReview: "Lascia una recensione Google", reviewHint: "La recensione si apre direttamente su Google.", bookIntro: "Il tuo tavolo ti aspetta.", bookText: "Scegli un giorno e un orario disponibili.", findUs: "A presto, a Sousse.", add: "Aggiungi", officialMenu: "Menù Per Voi", maps: "Apri in Maps", call: "Chiamaci", host: "Area proprietario", whatsapp: "Prenota su WhatsApp" },
  ar: { house: "عن المطعم", menu: "القائمة", gallery: "الصور", reviews: "التقييمات", find: "موقعنا", reserve: "احجز", reserveTable: "احجز طاولة", discover: "اكتشف القائمة", story: "قصتنا", scroll: "مرر للأسفل", restaurant: "مطعم إيطالي في سوسة", cuisine: "مطبخ إيطالي بروح متوسطية", houseTitle: "مائدة إيطالية بروح تونسية.", menuTitle: "اختر واستمتع.", completeMenu: "القائمة الكاملة", menuFor: "جميع أطباق وأسعار بير فوي.", galleryTitle: "مذاق التفاصيل.", reviewTitle: "ماذا يقولون عن بير فوي.", leaveReview: "اترك تقييماً على Google", reviewHint: "سيُفتح تقييمك مباشرة على Google.", bookIntro: "طاولتك في انتظارك.", bookText: "اختر يوماً ووقتاً متاحاً.", findUs: "نراك قريباً في سوسة.", add: "أضف", officialMenu: "قائمة بير فوي", maps: "افتح الخريطة", call: "اتصل بنا", host: "مساحة المالك", whatsapp: "احجز عبر WhatsApp" },
};

const formLabels: Record<Language, Record<string, string>> = {
  fr: { request:"Demande de réservation", name:"Votre nom", date:"Date", time:"Heure", guests:"Personnes", phone:"Téléphone", email:"Email (facultatif)", note:"Note (facultatif)", chooseDate:"Choisir une date d'abord", chooseTime:"Choisir un créneau", chooseGuests:"Choisir", send:"Envoyer la demande", disclaimer:"{formLabels[language].disclaimer}", pickup:"À emporter", delivery:"Livraison", address:"Adresse", order:"Passer la commande", total:"Total", yourOrder:"Votre commande" },
  en: { request:"Reservation request", name:"Your name", date:"Date", time:"Time", guests:"Guests", phone:"Phone", email:"Email (optional)", note:"Note (optional)", chooseDate:"Choose a date first", chooseTime:"Choose a time", chooseGuests:"Choose", send:"Send request", disclaimer:"Full or closed time slots are not offered.", pickup:"Pickup", delivery:"Delivery", address:"Address", order:"Place order", total:"Total", yourOrder:"Your order" },
  it: { request:"Richiesta di prenotazione", name:"Il tuo nome", date:"Data", time:"Ora", guests:"Persone", phone:"Telefono", email:"Email (facoltativa)", note:"Nota (facoltativa)", chooseDate:"Scegli prima una data", chooseTime:"Scegli un orario", chooseGuests:"Scegli", send:"Invia la richiesta", disclaimer:"Gli orari completi o chiusi non vengono mostrati.", pickup:"Da asporto", delivery:"Consegna", address:"Indirizzo", order:"Invia ordine", total:"Totale", yourOrder:"Il tuo ordine" },
  ar: { request:"طلب حجز", name:"اسمك", date:"التاريخ", time:"الوقت", guests:"عدد الأشخاص", phone:"الهاتف", email:"البريد الإلكتروني (اختياري)", note:"ملاحظة (اختياري)", chooseDate:"اختر التاريخ أولاً", chooseTime:"اختر الوقت", chooseGuests:"اختر", send:"إرسال الطلب", disclaimer:"لا تظهر الأوقات الممتلئة أو المغلقة.", pickup:"استلام", delivery:"توصيل", address:"العنوان", order:"إرسال الطلب", total:"المجموع", yourOrder:"طلبك" }
};
const siteCopy: Record<Language, Record<string, string>> = {
  fr: { heroTitle:"La dolce vita", heroTitleAccent:"à votre table.", heroCopy:"Une cuisine italienne sincère, généreuse et solaire. Des pâtes fraîches, des produits choisis, et le plaisir d'être ensemble.", introEyebrow:"Benvenuti da Per Voi", introTitle:"Une table italienne", introAccent:"avec une âme tunisienne.", introCopy:"Chez Per Voi, l'Italie se raconte sans détour : dans une pâte faite avec patience, une sauce qui mijote, un verre partagé. Notre cuisine puise dans les gestes italiens et dans la lumière de Sousse.", visitCta:"Venir nous voir", welcome:"L'art de recevoir, tout simplement.", gallery:"La galerie", instagram:"Voir Instagram", galleryNote:"Photos fournies par Per Voi · Autocollants retirés et images nettoyées pour la présentation du site.", reviews:"Les avis", google:"sur Google · 286 avis", reviewSource:"Avis Google publics repris via Restaurant Guru · noms, notes et dates affichés selon les informations visibles.", dayHours:"Mardi — dimanche · 12h — 23h", closed:"Lundi fermé · réservation conseillée", serviceNote:"Les demandes sont enregistrées et confirmées par l'équipe Per Voi.", locationCopy:"Per Voi vous accueille à Sahloul, Sousse. Venez découvrir une table pensée pour les bons moments.", open:"À bientôt", days:"Mardi — Dimanche", orderNote:"{siteCopy[language].orderNote}", quantity:"/ unité", person:"personne", people:"personnes", close:"Fermer", orderReceived:"Ordre reçu.", orderReceivedCopy:"Per Voi vous contactera pour confirmer votre commande et le délai.", backMenu:"Retour à la carte", requestSent:"Votre demande est bien enregistrée. Notre équipe vous appellera au numéro fourni pour confirmer la table.", anotherRequest:"Faire une autre demande" },
  en: { heroTitle:"La dolce vita", heroTitleAccent:"at your table.", heroCopy:"Sincere, generous and sunny Italian cuisine. Fresh pasta, carefully chosen ingredients, and the pleasure of being together.", introEyebrow:"Benvenuti da Per Voi", introTitle:"An Italian table", introAccent:"with a Tunisian soul.", introCopy:"At Per Voi, Italy is told without detours: through patiently made pasta, a gently simmered sauce and a glass shared together. Our cuisine draws on Italian gestures and the light of Sousse.", visitCta:"Come and see us", welcome:"The art of welcoming, simply.", gallery:"The gallery", instagram:"View Instagram", galleryNote:"Photos provided by Per Voi · Stickers removed and images cleaned for the website presentation.", reviews:"Reviews", google:"on Google · 286 reviews", reviewSource:"Public Google reviews sourced through Restaurant Guru · names, ratings and dates shown as publicly visible.", dayHours:"Tuesday — Sunday · 12pm — 11pm", closed:"Monday closed · reservations recommended", serviceNote:"Requests are recorded and confirmed by the Per Voi team.", locationCopy:"Per Voi welcomes you in Sahloul, Sousse. Discover a table designed for good moments.", open:"See you soon", days:"Tuesday — Sunday", orderNote:"Pay on delivery or pickup. Your order is confirmed by phone.", quantity:"/ unit", person:"person", people:"people", close:"Close", orderReceived:"Order received.", orderReceivedCopy:"Per Voi will contact you to confirm your order and timing.", backMenu:"Back to the menu", requestSent:"Your request has been recorded. Our team will call the number provided to confirm your table.", anotherRequest:"Make another request" },
  it: { heroTitle:"La dolce vita", heroTitleAccent:"alla tua tavola.", heroCopy:"Una cucina italiana sincera, generosa e solare. Pasta fresca, ingredienti scelti e il piacere di stare insieme.", introEyebrow:"Benvenuti da Per Voi", introTitle:"Una tavola italiana", introAccent:"con un'anima tunisina.", introCopy:"Da Per Voi l'Italia si racconta senza mezzi termini: nella pasta fatta con pazienza, in una salsa che cuoce lentamente e in un calice condiviso. La nostra cucina nasce dai gesti italiani e dalla luce di Sousse.", visitCta:"Vieni a trovarci", welcome:"L'arte dell'accoglienza, semplicemente.", gallery:"La galleria", instagram:"Vedi Instagram", galleryNote:"Foto fornite da Per Voi · Adesivi rimossi e immagini pulite per la presentazione del sito.", reviews:"Recensioni", google:"su Google · 286 recensioni", reviewSource:"Recensioni Google pubbliche tramite Restaurant Guru · nomi, voti e date mostrati come visibili pubblicamente.", dayHours:"Martedì — domenica · 12:00 — 23:00", closed:"Lunedì chiuso · prenotazione consigliata", serviceNote:"Le richieste vengono registrate e confermate dal team Per Voi.", locationCopy:"Per Voi ti accoglie a Sahloul, Sousse. Scopri una tavola pensata per i momenti belli.", open:"A presto", days:"Martedì — Domenica", orderNote:"Pagamento alla consegna o al ritiro. L'ordine viene confermato per telefono.", quantity:"/ unità", person:"persona", people:"persone", close:"Chiudi", orderReceived:"Ordine ricevuto.", orderReceivedCopy:"Per Voi ti contatterà per confermare l'ordine e i tempi.", backMenu:"Torna al menù", requestSent:"La richiesta è stata registrata. Il nostro team chiamerà il numero fornito per confermare il tavolo.", anotherRequest:"Fai un'altra richiesta" },
  ar: { heroTitle:"لا دولتشي فيتا", heroTitleAccent:"على طاولتكم.", heroCopy:"مطبخ إيطالي صادق، غني ومشرق. معكرونة طازجة، مكونات مختارة ومتعة اللقاء.", introEyebrow:"أهلاً بكم في بير فوي", introTitle:"مائدة إيطالية", introAccent:"بروح تونسية.", introCopy:"في بير فوي، تُروى إيطاليا ببساطة: في العجين المحضر بصبر، والصلصة المطهوة بهدوء، والكأس الذي نتشاركه. يستلهم مطبخنا الحركات الإيطالية وضوء سوسة.", visitCta:"تفضلوا بزيارتنا", welcome:"فن الضيافة ببساطة.", gallery:"الصور", instagram:"شاهد Instagram", galleryNote:"صور مقدمة من بير فوي · تمت إزالة الملصقات وتنظيف الصور لعرضها على الموقع.", reviews:"التقييمات", google:"على Google · 286 تقييماً", reviewSource:"تقييمات Google العامة عبر Restaurant Guru · الأسماء والتقييمات والتواريخ كما تظهر للعامة.", dayHours:"الثلاثاء — الأحد · 12:00 — 23:00", closed:"الاثنين مغلق · ينصح بالحجز", serviceNote:"يتم تسجيل الطلبات وتأكيدها من فريق بير فوي.", locationCopy:"يستقبلكم بير فوي في سهلول، سوسة. اكتشفوا مائدة صممت للحظات الجميلة.", open:"إلى اللقاء", days:"الثلاثاء — الأحد", orderNote:"الدفع عند التوصيل أو الاستلام. يتم تأكيد الطلب عبر الهاتف.", quantity:"/ الوحدة", person:"شخص", people:"أشخاص", close:"إغلاق", orderReceived:"تم استلام الطلب.", orderReceivedCopy:"سيتصل بكم بير فوي لتأكيد الطلب والمدة.", backMenu:"العودة إلى القائمة", requestSent:"تم تسجيل طلبكم. سيتصل فريقنا بالرقم المقدم لتأكيد الطاولة.", anotherRequest:"إرسال طلب آخر" }
};
const galleryCopy: Record<Language, Array<{ title: string; caption: string }>> = {
  fr: [{ title:"La salle", caption:"Lumière, arches & dolce vita" }, { title:"La pizza", caption:"Pâte levée, four & basilic" }, { title:"Les cocktails", caption:"Fraîcheur, agrumes & partage" }, { title:"La pasta", caption:"Des recettes généreuses" }, { title:"Les raviolis", caption:"Fait maison, avec amore" }, { title:"Les classiques", caption:"Le goût du vrai" }, { title:"Le dessert", caption:"La dernière touche" }, { title:"À partager", caption:"Une cuisine qui rassemble" }],
  en: [{ title:"The room", caption:"Light, arches & dolce vita" }, { title:"The pizza", caption:"Risen dough, oven & basil" }, { title:"Cocktails", caption:"Freshness, citrus & sharing" }, { title:"The pasta", caption:"Generous recipes" }, { title:"The ravioli", caption:"Homemade, with amore" }, { title:"The classics", caption:"The taste of the real" }, { title:"Dessert", caption:"The final touch" }, { title:"To share", caption:"A cuisine that brings us together" }],
  it: [{ title:"La sala", caption:"Luce, archi & dolce vita" }, { title:"La pizza", caption:"Impasto, forno & basilico" }, { title:"I cocktail", caption:"Freschezza, agrumi & condivisione" }, { title:"La pasta", caption:"Ricette generose" }, { title:"I ravioli", caption:"Fatti in casa, con amore" }, { title:"I classici", caption:"Il gusto autentico" }, { title:"Il dolce", caption:"Il tocco finale" }, { title:"Da condividere", caption:"Una cucina che unisce" }],
  ar: [{ title:"القاعة", caption:"ضوء وأقواس ولا دولتشي فيتا" }, { title:"البيتزا", caption:"عجين مخمر وفرن وريحان" }, { title:"المشروبات", caption:"انتعاش وحمضيات ومشاركة" }, { title:"المعكرونة", caption:"وصفات غنية" }, { title:"الرافيولي", caption:"محضر في المطعم بحب" }, { title:"الأطباق الكلاسيكية", caption:"المذاق الأصيل" }, { title:"الحلوى", caption:"اللمسة الأخيرة" }, { title:"للمشاركة", caption:"مطبخ يجمعنا" }]
};

const customerReviews = [
  { quote: "Restaurant très accueillant sympathique et délicieux.", author: "Momo Farhat", detail: "Avis Google · 5/5 · il y a 23 jours" },
  { quote: "A modern restaurant & lifestyle spot where great food, signature mocktails, music, and a unique atmosphere come together. A place to eat, relax, connect, and enjoy unforgettable moments.", author: "Omar Hajamor", detail: "Avis Google · 5/5 · il y a 23 jours" },
  { quote: "Tres Bonne experience le service etait excellent a refaire la prochaine fois.", author: "sabi.fareh1@gmail.com 22689814", detail: "Avis Google · 5/5 · il y a 23 jours" },
  { quote: "Très belle expérience au restaurant Per Voi ! Les pizzas sont magnifiques, très bonnes et préparées avec des produits de qualité. Les entrées étaient également excellentes, même si les portions sont assez généreuses et consistantes. Nous avons eu un petit souci avec la cuisson de la viande, mais l’équipe a très bien réagi et a su se rattraper rapidement. Un très bon dessert nous a même été offert en geste commercial, ce que nous avons beaucoup apprécié. Le cadre est vraiment beau, le service agréable et surtout la qualité des plats est au rendez-vous. Une très bonne adresse que je recommande !", author: "A M", detail: "Avis Google · 5/5 · il y a 23 jours" },
  { quote: "Honnêtement une ambiance européenne très agréable et chaleureuse!", author: "Ahmed Zguem", detail: "Avis Google · 5/5 · il y a 23 jours" },
  { quote: "Très bel endroit. Service agréable. Très bien service. Pizza très bonne.", author: "Angelique Cossinet", detail: "Avis Google · 5/5 · il y a 23 jours" },
  { quote: "Très bon, restaurant jolie rien à dire.", author: "Ymène Zouaghi", detail: "Avis Google · 5/5 · il y a 25 jours" },
  { quote: "Je suis partie manger chez eux et c’était vraiment excellent, très très bon ! Le cousin du propriétaire nous a super bien accueillis. Il a même acheté des sucettes pour ma fille, une petite attention qui nous a vraiment fait plaisir. Je recommande vraiment, on a passé un très bon moment !", author: "Ib Marie", detail: "Avis Google · 5/5 · il y a 27 jours" },
];

const ownerGallery = [
  { src: "/manus-storage/enhanced-01_3699216b.png", alt: "Salle principale de Per Voi", title: "La salle", caption: "Lumière, arches & dolce vita" },
  { src: "/manus-storage/enhanced-05_20d0eabf.png", alt: "Pizza de Per Voi", title: "La pizza", caption: "Pâte levée, four & basilic" },
  { src: "/manus-storage/enhanced-04_16e88191.png", alt: "Cocktails frais de Per Voi", title: "Les cocktails", caption: "Fraîcheur, agrumes & partage" },
  { src: "/manus-storage/enhanced-07_74d83e52.png", alt: "Penne crémeuses de Per Voi", title: "La pasta", caption: "Des recettes généreuses" },
  { src: "/manus-storage/enhanced-11_584a344d.png", alt: "Raviolis maison de Per Voi", title: "Les raviolis", caption: "Fait maison, avec amore" },
  { src: "/manus-storage/enhanced-12_96fcf87e.png", alt: "Tagliatelles bolognaises de Per Voi", title: "Les classiques", caption: "Le goût du vrai" },
  { src: "/manus-storage/enhanced-02_6cfe19b4.png", alt: "Dessert au cacao de Per Voi", title: "Le dessert", caption: "La dernière touche" },
  { src: "/manus-storage/enhanced-14_9d948ab5.png", alt: "Assiette gourmande de Per Voi", title: "À partager", caption: "Une cuisine qui rassemble" },
];

type LiveMenuItem = {
  id: number;
  category: string;
  name: string;
  description: string | null;
  priceDt: number;
  active: boolean;
  sortOrder: number;
};

const fallbackItems: LiveMenuItem[] = [
  { id: -1, category: "Entrées", name: "Burrata", description: "Marmelade de tomates, pickles de gingembre et crème citronnée.", priceDt: 27, active: true, sortOrder: 1 },
  { id: -2, category: "Pâtes", name: "Rigatoni Effiloché de Bœuf", description: "Sauce tomates, tomates séchées et crème de parmesan.", priceDt: 36, active: true, sortOrder: 2 },
  { id: -3, category: "Pâtes", name: "Rigatoni Poivrons Fumés et Crevettes", description: "Miel, noisettes et figues séchées.", priceDt: 42, active: true, sortOrder: 3 },
  { id: -4, category: "Pizzas", name: "La Margherita", description: "Mozzarella, grana padano, basilic frais et huile d’olives.", priceDt: 22, active: true, sortOrder: 4 },
  { id: -5, category: "Desserts", name: "Tiramisu", description: "Café, mascarpone, langues de chat et cacao.", priceDt: 23, active: true, sortOrder: 5 },
];

export default function Home() {
  const [language, setLanguage] = useState<Language>(() => (localStorage.getItem("per-voi-language") as Language) || "fr");
  const t = translations[language];
  const menuQuery = trpc.restaurant.menu.list.useQuery();
  const menuItems = (menuQuery.data as LiveMenuItem[] | undefined) ?? fallbackItems;
  const categories = useMemo(() => Array.from(new Set(menuItems.map(item => item.category))), [menuItems]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [category, setCategory] = useState("Pâtes");
  const [submitted, setSubmitted] = useState(false);
  const [reservationDate, setReservationDate] = useState("");
  const [reservationTime, setReservationTime] = useState("");
  const [orderOpen, setOrderOpen] = useState(false);
  const [orderSubmitted, setOrderSubmitted] = useState(false);
  const [cart, setCart] = useState<Record<number, { item: LiveMenuItem; quantity: number }>>({});
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [orderType, setOrderType] = useState<"pickup" | "delivery">("pickup");
  const [address, setAddress] = useState("");
  const [orderNotes, setOrderNotes] = useState("");
  const [reviewIndex, setReviewIndex] = useState(0);

  useEffect(() => {
    localStorage.setItem("per-voi-language", language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    document.title = language === "ar" ? "بير فوي — مطعم إيطالي في سوسة" : language === "en" ? "Per Voi — Italian restaurant in Sousse" : language === "it" ? "Per Voi — Ristorante italiano a Sousse" : "Per Voi — Restaurant italien à Sousse";
  }, [language]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setReviewIndex(current => (current + 1) % customerReviews.length);
    }, 5500);
    return () => window.clearInterval(timer);
  }, []);

  const availabilityQuery = trpc.restaurant.availability.forDate.useQuery(
    { serviceDate: reservationDate },
    { enabled: reservationDate.length === 10 },
  );
  const reservationMutation = trpc.restaurant.reservations.create.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Votre demande est bien envoyée", { description: "Per Voi vous recontactera pour confirmer votre table." });
    },
    onError: error => toast.error("Réservation impossible", { description: error.message }),
  });
  const orderMutation = trpc.restaurant.orders.create.useMutation({
    onSuccess: result => {
      setOrderSubmitted(true);
      setCart({});
      toast.success(`Commande #${result.id} reçue`, { description: "Per Voi va vous contacter pour confirmer la commande." });
    },
    onError: error => toast.error("Commande impossible", { description: error.message }),
  });

  const visibleItems = menuItems.filter(item => item.category === category);
  const cartLines = Object.values(cart);
  const cartCount = cartLines.reduce((sum, line) => sum + line.quantity, 0);
  const cartTotal = cartLines.reduce((sum, line) => sum + line.item.priceDt * line.quantity, 0);
  const availableTimes = availabilityQuery.data?.filter(slot => slot.status === "available") ?? [];

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  const addToCart = (item: LiveMenuItem) => {
    if (item.id < 0) {
      toast.info("La carte se charge encore", { description: "Réessayez dans un instant." });
      return;
    }
    setCart(current => ({ ...current, [item.id]: { item, quantity: (current[item.id]?.quantity ?? 0) + 1 } }));
    toast.success(`${item.name} ajouté`, { description: "Votre panier est prêt à être commandé." });
  };

  const changeQuantity = (id: number, delta: number) => {
    setCart(current => {
      const line = current[id];
      if (!line) return current;
      const quantity = line.quantity + delta;
      if (quantity <= 0) {
        const next = { ...current };
        delete next[id];
        return next;
      }
      return { ...current, [id]: { ...line, quantity } };
    });
  };

  const handleReservation = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    reservationMutation.mutate({
      name: String(data.get("name") ?? ""),
      phone: String(data.get("phone") ?? ""),
      email: String(data.get("email") ?? ""),
      serviceDate: reservationDate,
      serviceTime: reservationTime,
      guests: Number(data.get("guests") ?? 0),
      notes: String(data.get("notes") ?? ""),
    });
  };

  const handleOrder = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    orderMutation.mutate({
      customerName,
      phone,
      orderType,
      address: address || undefined,
      notes: orderNotes || undefined,
      items: cartLines.map(line => ({ menuItemId: line.item.id, quantity: line.quantity })),
    });
  };

  return (
    <main className={`site-shell language-transition language-${language}`} key={language}>
      <div className="topline"><div className="container topline-inner"><span>Sousse · 4054</span><span className="topline-center">{t.cuisine}</span><span className="rating-mini"><Star size={13} fill="currentColor" /> 4,7 <em>· 286 avis</em></span></div></div>
      <header className="nav-wrap"><div className="container nav-inner">
        <button className="brand" onClick={() => scrollTo("accueil")} aria-label="Retour à l'accueil"><span className="brand-mark">PV</span><span className="brand-wordmark">Per Voi</span></button>
        <nav className={menuOpen ? "main-nav is-open" : "main-nav"} aria-label="Navigation principale">
          <button onClick={() => scrollTo("histoire")}>{t.house}</button><button onClick={() => scrollTo("carte")}>{t.menu}</button><button onClick={() => scrollTo("galerie")}>{t.gallery}</button><button onClick={() => scrollTo("avis")}>{t.reviews}</button><button onClick={() => scrollTo("visiter")}>{t.find}</button><button className="nav-mobile-cta" onClick={() => scrollTo("reservation")}>{t.reserveTable}</button>
        </nav>
        <div className="nav-actions"><div className="language-switcher" aria-label="Choisir la langue">{(Object.keys(languageLabels) as Language[]).map(code => <button key={code} type="button" className={language === code ? "active" : ""} onClick={() => setLanguage(code)} aria-label={`Language ${languageLabels[code]}`} title={languageLabels[code]}><span aria-hidden="true">{languageFlags[code]}</span><span>{languageCodes[code]}</span></button>)}</div><button className="icon-button mobile-trigger" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Fermer le menu" : "Ouvrir le menu"}>{menuOpen ? <X size={21} /> : <Menu size={21} />}</button><button className="button button-dark nav-cta" onClick={() => scrollTo("reservation")}>{t.reserve} <ArrowRight size={16} /></button></div>
      </div></header>

      <section className="hero" id="accueil"><div className="hero-image" /><div className="hero-overlay" /><div className="container hero-content"><div className="hero-kicker reveal"><span className="kicker-line" /> {t.restaurant}</div><h1 className="hero-title reveal delay-1">{siteCopy[language].heroTitle},<br /><i>{siteCopy[language].heroTitleAccent}</i></h1><p className="hero-copy reveal delay-2">{siteCopy[language].heroCopy}</p><div className="hero-actions reveal delay-3"><button className="button button-light" onClick={() => scrollTo("carte")}>{t.discover} <ArrowRight size={16} /></button><button className="text-link text-link-light" onClick={() => scrollTo("histoire")}>{t.story} <ArrowDown size={15} /></button></div></div><div className="hero-side-note">PER VOI <span>·</span> 01</div><div className="hero-bottom container"><span className="scroll-note"><span className="scroll-dot" /> {t.scroll}</span><span className="hero-price">30 — 90 DT <em>{language === "fr" ? "par personne" : language === "ar" ? "للشخص" : language === "it" ? "a persona" : "per person"}</em></span></div></section>

      <section className="intro-section section-padding" id="histoire"><div className="container intro-grid"><div className="section-eyebrow">01 <span /> {t.house}</div><div className="intro-statement"><p className="eyebrow-label">{siteCopy[language].introEyebrow}</p><h2>{siteCopy[language].introTitle}<br /><i>{siteCopy[language].introAccent}</i></h2><p className="intro-text">{siteCopy[language].introCopy}</p><button className="text-link" onClick={() => scrollTo("visiter")}>{siteCopy[language].visitCta} <ArrowRight size={16} /></button></div><div className="intro-image-frame"><img src="/manus-storage/enhanced-03_94d04b86.png" alt="Salle chaleureuse et méditerranéenne de Per Voi" /><span className="image-caption">{siteCopy[language].welcome}</span></div></div></section>

      <section className="menu-section section-padding" id="carte"><div className="container"><div className="menu-heading"><div><div className="section-eyebrow">02 <span /> {t.completeMenu}</div><h2>{t.menuTitle}</h2></div><div className="menu-heading-note">{t.menuFor}</div></div><div className="menu-layout"><div className="menu-list-wrap"><div className="category-tabs" role="tablist" aria-label="Catégories de menu">{categories.map(item => <button key={item} role="tab" aria-selected={category === item} className={category === item ? "active" : ""} onClick={() => setCategory(item)}>{translateMenuText(language, item)}</button>)}</div><div className="menu-items">{visibleItems.map((item, index) => <article className="menu-item" key={item.id}><div className="menu-item-index">{String(index + 1).padStart(2, "0")}</div><div className="menu-item-body"><h3>{translateMenuText(language, item.name)}</h3><p>{translateMenuText(language, item.description)}</p></div><div className="menu-item-action"><span className="menu-item-price">{item.priceDt} DT</span><button className="menu-add" onClick={() => addToCart(item)}><Plus size={14} /> {t.add}</button></div></article>)}</div></div></div></div></section>

      <section className="gallery-section section-padding" id="galerie"><div className="container"><div className="gallery-heading"><div><div className="section-eyebrow">02 bis <span /> {siteCopy[language].gallery}</div><h2>{t.galleryTitle}</h2></div><a className="text-link" href="https://www.instagram.com/pervoi_restaurant/" target="_blank" rel="noreferrer">{siteCopy[language].instagram} <Instagram size={16} /></a></div><div className="gallery-grid">{ownerGallery.map((photo, index) => <figure className={`gallery-card ${index === 0 ? "gallery-card-large" : ""} ${index === 2 ? "gallery-card-offset" : ""}`} key={photo.src}><img src={photo.src} alt={photo.alt} loading={index > 1 ? "lazy" : "eager"} /><figcaption><span>{String(index + 1).padStart(2, "0")}</span><strong>{galleryCopy[language][index].title}</strong><em>{galleryCopy[language][index].caption}</em></figcaption></figure>)}</div><p className="gallery-note">{siteCopy[language].galleryNote}</p></div></section>

      <section className="quote-band" id="avis"><div className="container reviews-container"><div className="reviews-heading"><div><div className="section-eyebrow">02 ter <span /> {siteCopy[language].reviews}</div><h2>{t.reviewTitle}</h2></div><div className="quote-meta"><div className="stars"><Star size={15} fill="currentColor" /><Star size={15} fill="currentColor" /><Star size={15} fill="currentColor" /><Star size={15} fill="currentColor" /><Star size={15} fill="currentColor" /></div><strong>4,7 / 5</strong><span>{siteCopy[language].google}</span></div></div><div className="review-carousel"><div className="review-quote-mark">“</div><div className="review-slide review-slide-enter" key={reviewIndex}><div className="review-stars"><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /></div><blockquote>{customerReviews[reviewIndex].quote}</blockquote><div className="review-author"><strong>{customerReviews[reviewIndex].author}</strong><span>{customerReviews[reviewIndex].detail}</span></div></div><div className="review-controls"><button onClick={() => setReviewIndex(current => (current - 1 + customerReviews.length) % customerReviews.length)} aria-label="Avis précédent"><ChevronLeft size={18} /></button><span>{String(reviewIndex + 1).padStart(2, "0")} / {String(customerReviews.length).padStart(2, "0")}</span><button onClick={() => setReviewIndex(current => (current + 1) % customerReviews.length)} aria-label="Avis suivant"><ChevronRight size={18} /></button></div></div><p className="review-source">{siteCopy[language].reviewSource}</p><div className="review-actions"><a className="button button-light" href={googleReviewLink} target="_blank" rel="noreferrer">{t.leaveReview} <ArrowRight size={16} /></a><span>{t.reviewHint}</span></div></div></section>

      <section className="reservation-section section-padding" id="reservation"><div className="container reservation-grid"><div className="reservation-intro"><div className="section-eyebrow">03 <span /> {siteCopy[language].heroTitle}</div><h2>{t.bookIntro}</h2><p>{t.bookText} {siteCopy[language].serviceNote}</p><div className="reservation-details"><span><Clock3 size={17} /> {siteCopy[language].dayHours}</span><span><CalendarDays size={17} /> {siteCopy[language].closed}</span></div></div><div className="reservation-card">{submitted ? <div className="submitted-state"><div className="success-icon"><Check size={24} /></div><h3>Grazie mille.</h3><p>{siteCopy[language].requestSent}</p><button className="text-link" onClick={() => setSubmitted(false)}>{siteCopy[language].anotherRequest} <ArrowRight size={16} /></button></div> : <form onSubmit={handleReservation}><div className="form-topline"><span>{formLabels[language].request}</span><span>03 / 04</span></div><label>{formLabels[language].name}<input required name="name" placeholder="Ex. Amira Ben Ali" /></label><div className="form-row"><label>{formLabels[language].date}<input required type="date" name="date" min={new Date().toISOString().slice(0, 10)} value={reservationDate} onChange={event => { setReservationDate(event.target.value); setReservationTime(""); }} /></label><label>{formLabels[language].time}<select required name="time" value={reservationTime} onChange={event => setReservationTime(event.target.value)}><option value="">{reservationDate ? formLabels[language].chooseTime : formLabels[language].chooseDate}</option>{availableTimes.map(slot => <option key={slot.serviceTime} value={slot.serviceTime}>{slot.serviceTime}</option>)}</select></label></div><div className="form-row"><label>{formLabels[language].guests}<select required name="guests" defaultValue=""><option value="" disabled>{formLabels[language].chooseGuests}</option>{[1,2,3,4,5,6,7,8,9,10].map(value => <option key={value} value={value}>{value} {language === "fr" ? `personne${value > 1 ? "s" : ""}` : language === "ar" ? "شخص" : language === "it" ? `person${value > 1 ? "e" : "a"}` : `person${value > 1 ? "s" : ""}`}</option>)}</select></label><label>{formLabels[language].phone}<input required name="phone" placeholder="20 217 090" /></label></div><label>{formLabels[language].email}<input type="email" name="email" placeholder="vous@exemple.com" /></label><label>{formLabels[language].note}<input name="notes" placeholder="Anniversaire, chaise bébé…" /></label><button className="button button-dark button-wide" type="submit" disabled={reservationMutation.isPending}>{reservationMutation.isPending ? "Envoi…" : formLabels[language].send} <ArrowRight size={16} /></button><p className="form-disclaimer">{formLabels[language].disclaimer}</p></form>}</div></div></section>

      <section className="visit-section" id="visiter"><div className="container visit-grid"><div className="visit-copy"><div className="section-eyebrow">04 <span /> {t.findUs}</div><h2>{t.findUs}</h2><p>{siteCopy[language].locationCopy}</p><div className="visit-actions"><a className="button button-light" href={mapLink} target="_blank" rel="noreferrer">{t.maps} <MapPin size={16} /></a><a className="text-link text-link-light" href="tel:+21620217090">{t.call} <Phone size={15} /></a></div></div><div className="visit-card"><div className="visit-card-top"><span>Per Voi</span><span className="open-pill"><span /> {siteCopy[language].open}</span></div><div className="visit-address"><MapPin size={20} /><div><strong>Sahloul · Sousse</strong><span>+216 20 217 090</span></div></div><div className="visit-hours"><span>{siteCopy[language].days}</span><strong>12:00 — 23:00</strong></div><div className="visit-socials"><a href="https://www.instagram.com/pervoi_restaurant/" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={18} /></a><a href={whatsappLink} target="_blank" rel="noreferrer" aria-label="WhatsApp"><MessageCircle size={18} /></a></div></div></div></section>

      <footer className="footer"><div className="container footer-inner"><div className="footer-brand"><span className="brand-mark">PV</span><span className="brand-wordmark">Per Voi</span></div><p>{siteCopy[language].heroTitle}</p><div className="footer-links"><a href="/hote">{t.host}</a><span className="footer-copy">© 2026 Per Voi · Sousse</span></div></div></footer>
      <a className="whatsapp-float" href={whatsappLink} target="_blank" rel="noreferrer" aria-label="Contacter Per Voi sur WhatsApp"><MessageCircle size={23} /><span>{t.whatsapp}</span></a>
      {cartCount > 0 && <button className="cart-float" onClick={() => setOrderOpen(true)}><ShoppingBag size={18} /><span>{cartCount} {cartCount > 1 ? siteCopy[language].people : siteCopy[language].person}</span><strong>{cartTotal} DT</strong></button>}
      {orderOpen && <div className="order-overlay" role="dialog" aria-modal="true" aria-label={siteCopy[language].yourOrder}><div className="order-panel"><div className="order-panel-head"><div><span className="eyebrow-label">Per Voi à emporter</span><h2>{formLabels[language].yourOrder}</h2></div><button className="icon-button" onClick={() => setOrderOpen(false)} aria-label={siteCopy[language].close}><X /></button></div>{orderSubmitted ? <div className="submitted-state"><div className="success-icon"><Check size={24} /></div><h3>{siteCopy[language].orderReceived}</h3><p>{siteCopy[language].orderReceivedCopy}</p><button className="text-link" onClick={() => { setOrderSubmitted(false); setOrderOpen(false); }}>{siteCopy[language].backMenu} <ArrowRight size={16} /></button></div> : <form onSubmit={handleOrder}><div className="order-lines">{cartLines.map(line => <div className="order-line" key={line.item.id}><div><strong>{line.item.name}</strong><span>{line.item.priceDt} DT {siteCopy[language].quantity}</span></div><div className="quantity-control"><button type="button" onClick={() => changeQuantity(line.item.id, -1)} aria-label="Diminuer"><Minus size={13} /></button><span>{line.quantity}</span><button type="button" onClick={() => changeQuantity(line.item.id, 1)} aria-label="Augmenter"><Plus size={13} /></button></div></div>)}</div><div className="order-total"><span>{formLabels[language].total}</span><strong>{cartTotal} DT</strong></div><label>{formLabels[language].name}<input required value={customerName} onChange={event => setCustomerName(event.target.value)} placeholder="Nom complet" /></label><label>{formLabels[language].phone}<input required value={phone} onChange={event => setPhone(event.target.value)} placeholder="20 217 090" /></label><div className="form-row"><label>{formLabels[language].order}<select value={orderType} onChange={event => setOrderType(event.target.value as "pickup" | "delivery")}><option value="pickup">{formLabels[language].pickup}</option><option value="delivery">{formLabels[language].delivery}</option></select></label><label>{formLabels[language].address}{orderType === "delivery" ? <input required value={address} onChange={event => setAddress(event.target.value)} placeholder="Adresse de livraison" /> : <input value="Sahloul, Sousse" readOnly />}</label></div><label>{formLabels[language].note}<input value={orderNotes} onChange={event => setOrderNotes(event.target.value)} placeholder={language === "fr" ? "Précision pour la cuisine" : language === "en" ? "Note for the kitchen" : language === "it" ? "Nota per la cucina" : "ملاحظة للمطبخ"} /></label><button className="button button-dark button-wide" type="submit" disabled={orderMutation.isPending}>{orderMutation.isPending ? "Envoi…" : formLabels[language].order} <ArrowRight size={16} /></button><p className="form-disclaimer">{siteCopy[language].orderNote}</p></form>}</div></div>}
    </main>
  );
}
